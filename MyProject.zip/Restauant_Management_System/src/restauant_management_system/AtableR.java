
package restauant_management_system;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class AtableR extends javax.swing.JFrame {

   ResultSet rt;

   public AtableR() {
        initComponents();
        DefaultTableModel DC=(DefaultTableModel)rdisplay.getModel();
        DC.setRowCount(0);
          Restauant_Management_System Connection=new Restauant_Management_System();
        ResultSet rt = Connection.TRDisplayRecods();
         try {
             while(rt.next()){
           String data[]={rt.getString("RName"),Integer.toString(rt.getInt("RContact")),rt.getString("REmail"),rt.getString("RCnic"),rt.getString("RTableno"),rt.getString("RTime")};
                 DC.addRow(data);
             }    } catch (SQLException ex) {
             Logger.getLogger(AtableR.class.getName()).log(Level.SEVERE, null, ex);
         }
         
    
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        rtableno = new javax.swing.JComboBox<>();
        rtime = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        rcnic = new javax.swing.JTextField();
        rname = new javax.swing.JTextField();
        rcontact = new javax.swing.JTextField();
        remail = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        find = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        rdisplay = new javax.swing.JTable();
        search = new javax.swing.JTextField();
        table = new javax.swing.JTextField();
        time = new javax.swing.JTextField();
        jButton7 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        rtableno.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "1", "2", "3", "4", "5" }));
        rtableno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rtablenoActionPerformed(evt);
            }
        });
        jPanel2.add(rtableno, new org.netbeans.lib.awtextra.AbsoluteConstraints(102, 519, 224, -1));

        rtime.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select", "12:00pm", "1:00pm", "2:00pm", "3:00pm", "4:00pm", "5:00pm", "6:00pm", "7:00pm" }));
        rtime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rtimeActionPerformed(evt);
            }
        });
        jPanel2.add(rtime, new org.netbeans.lib.awtextra.AbsoluteConstraints(102, 613, 224, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("Contact");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 145, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("CNIC");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 356, -1, 35));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Name");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 44, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("Email");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 256, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setText("Time");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 578, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setText("Table no");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 481, -1, -1));

        rcnic.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel2.add(rcnic, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 400, 236, 43));

        rname.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel2.add(rname, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 82, 236, 43));

        rcontact.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel2.add(rcontact, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 197, 236, 43));

        remail.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel2.add(remail, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 295, 236, 43));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton1.setText("Book");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(344, 35, -1, -1));

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton3.setText("Cancel Reservation");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(436, 35, -1, -1));

        jButton4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton4.setText("Clear");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 40, -1, -1));

        jButton5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton5.setText("Back");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 660, -1, -1));

        find.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        find.setText("Search");
        find.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findActionPerformed(evt);
            }
        });
        jPanel2.add(find, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 40, -1, -1));

        rdisplay.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Name", "Contact", "Email", "CNIC", "Table no", "Time"
            }
        ));
        rdisplay.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rdisplayMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(rdisplay);
        if (rdisplay.getColumnModel().getColumnCount() > 0) {
            rdisplay.getColumnModel().getColumn(5).setResizable(false);
        }

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 80, 810, 560));

        search.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel2.add(search, new org.netbeans.lib.awtextra.AbsoluteConstraints(770, 40, 188, -1));

        table.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel2.add(table, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 400, -1, 43));

        time.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jPanel2.add(time, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 80, -1, 43));

        jButton7.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jButton7.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\close.png")); // NOI18N
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel7.setText("Table Reservation");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(438, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(376, 376, 376)
                .addComponent(jButton7)
                .addContainerGap())
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton7)
                        .addGap(18, 18, 18)))
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 703, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 776, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void rtablenoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rtablenoActionPerformed
        // TODO add your handling code here:
        String SelectedValue =rtableno.getSelectedItem().toString();
        table.setText(SelectedValue);
        
    }//GEN-LAST:event_rtablenoActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
 Restauant_Management_System db = new Restauant_Management_System();
DefaultTableModel tb=(DefaultTableModel)rdisplay.getModel();
        
//String SelectValue=rtableno.getSelectedItem().toString();
 //String SelectValue1=rtime.getSelectedItem().toString();
 
if (db.Booktable(rname.getText(),Integer.parseInt(rcontact.getText()), remail.getText(),rcnic.getText(),table.getText(),time.getText() ) == 1) {
    JOptionPane.showMessageDialog(this, " Booked", "Table Reservation", JOptionPane.INFORMATION_MESSAGE);
    rname.setText("");
    rcontact.setText("");
    remail.setText("");
    rcnic.setText("");
    table.setText("");
    time.setText("");
} else {
    JOptionPane.showMessageDialog(this, "Error", "Table Reservation", JOptionPane.ERROR_MESSAGE);
  
    }                                    
   try {
           
            
            rt=db.TDisplayRecods();
           tb.setRowCount(0);
            while(rt.next()){
            String data[]={rt.getString("RName"),Integer.toString(rt.getInt("RContact")),rt.getString("REmail"),rt.getString("RCnic"),rt.getString("RTableno"),rt.getString("RTime")};
            tb.addRow(data);    
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(AtableR.TRDisplayRecods.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void rtimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rtimeActionPerformed
        // TODO add your handling code here:
        String SelectedValue1 =rtime.getSelectedItem().toString();
        time.setText(SelectedValue1);
       
    }//GEN-LAST:event_rtimeActionPerformed

    private void rdisplayMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rdisplayMouseClicked
        // TODO add your handling code here:
        DefaultTableModel tb = (DefaultTableModel) rdisplay.getModel();
        
        String Rname=tb.getValueAt(rdisplay.getSelectedRow(),0).toString();
        String Rcontact=tb.getValueAt(rdisplay.getSelectedRow(),1).toString();
        String Remail=tb.getValueAt(rdisplay.getSelectedRow(),2).toString();
        String Rcnic=tb.getValueAt(rdisplay.getSelectedRow(),3).toString();
        String Rtable=tb.getValueAt(rdisplay.getSelectedRow(),4).toString();
        String Rtime=tb.getValueAt(rdisplay.getSelectedRow(),5).toString();
        
        rname.setText(Rname);
        rcontact.setText(Rcontact);
        remail.setText(Remail);
        rcnic.setText(Rcnic);
        table.setText(Rtable);
        time.setText(Rtime);
//        String comboSub =rdisplay.getValueAt(selectedRow, 4).toString();
//        for (
//                )
        
    }//GEN-LAST:event_rdisplayMouseClicked

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
    rname.setText("");
    rcontact.setText("");
    remail.setText("");
    rcnic.setText("");
    table.setText("");
    
        
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        int a=JOptionPane.showConfirmDialog(null,"Do you want to exist","Select",JOptionPane.YES_NO_OPTION);
        if(a==0){
         System.exit(0);
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        Dashboard D =new Dashboard();
        D.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void findActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findActionPerformed
        // TODO add your handling code here:
         try {
         // TODO add your handling code here:
           Restauant_Management_System db=new Restauant_Management_System();
         
         ResultSet rt;
         rt=db.findRTRecords(search.getText());
         DefaultTableModel tb=(DefaultTableModel)rdisplay.getModel();
         tb.setRowCount(0);
         while(rt.next()){
             String data[]={rt.getString("RName"),Integer.toString(rt.getInt("RContact")),rt.getString("REmail"),rt.getString("RCnic"),rt.getString("RTableno"),rt.getString("RTime")};
             tb.addRow(data);
         
         }
     } catch (SQLException ex) {
         Logger.getLogger(AtableR.class.getName()).log(Level.SEVERE, null, ex);
     }
    }//GEN-LAST:event_findActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        Restauant_Management_System db=new Restauant_Management_System();
         DefaultTableModel tb=(DefaultTableModel)rdisplay.getModel();
         String rowid=(String) tb.getValueAt(rdisplay.getSelectedRow(),0);
        if(db.RRemoveRecordBYID(rowid)==1){
        
            JOptionPane.showMessageDialog(this, "Removed","alert",1);
        }else{
        
        
            JOptionPane.showMessageDialog(this, "ERRor","alert",1);
        }
        
        
                try {
           
            
            rt=db.gettableRecords();
           tb.setRowCount(0);
            while(rt.next()){
            String data[]={rt.getString("RName"),Integer.toString(rt.getInt("RContact")),rt.getString("REmail"),rt.getString("RCnic"),rt.getString("RTableno"),rt.getString("RTime")};               
            tb.addRow(data);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(menud.DisplaystaffRecods.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AtableR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AtableR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AtableR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AtableR.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AtableR().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton find;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField rcnic;
    private javax.swing.JTextField rcontact;
    private javax.swing.JTable rdisplay;
    private javax.swing.JTextField remail;
    private javax.swing.JTextField rname;
    private javax.swing.JComboBox<String> rtableno;
    private javax.swing.JComboBox<String> rtime;
    private javax.swing.JTextField search;
    private javax.swing.JTextField table;
    private javax.swing.JTextField time;
    // End of variables declaration//GEN-END:variables

    private static class TRDisplayRecods {

        public TRDisplayRecods() {
        }
    }
}
