
package restauant_management_system;
//import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Restauant_Management_System {

   private  Connection con;
   private Statement st;
    private ResultSet rs;
    
     Restauant_Management_System(){
        
        try{
          
          Class.forName("com.mysql.cj.jdbc.Driver");
          con=DriverManager.getConnection("jdbc:mysql://localhost:3306/restauant_management_system", "root","");
          st=con.createStatement();
          System.out.println("DB is Connected");
       
        }catch(Exception e){
         System.out.println(e);
        }
       
    }
     public int CusSignup(int Cid,String CName,String CEmail, int CContact, String CPassword){
    int status=0;
        try {
            String sql="insert into usersu values('"+Cid+"','"+CName+"','"+CEmail+"','"+CContact+"','"+CPassword+"')";
            status=st.executeUpdate(sql);
        } catch (SQLException ex) {
            System.out.println(ex);
        
        }
        return status;
}
     
     public ResultSet LoginCustomer(String cname ,String apasword){
        try {
            String sql="select * from usersu where CName='"+cname+"' and CPassword='"+apasword+"'";
            rs=st.executeQuery(sql);
            System.out.println("hello");
            
        } catch (SQLException ex) {
            Logger.getLogger(Restauant_Management_System.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
        
    
}
     
  public ResultSet DisplayfooRecods(){

  String sql="select * from menu";
  try{
  rs=st.executeQuery(sql);
  }catch(SQLException e){
  
  System.out.println(e);
  }
  
  
  
  return rs;

}
  public ResultSet DisplaystaffRecods(){

  String sql="select * from staffa";
  try{
  rs=st.executeQuery(sql);
  }catch(SQLException e){
  
  System.out.println(e);
  }
  
  
  
  return rs;

}
  
  public ResultSet findFoodRecords(String searchdata){

        try {
            String sql="select * from fmenu where fid='"+searchdata+"' or fname='"+searchdata+"'";
            rs=st.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Restauant_Management_System.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return rs;
   
}
  public int updateMenuRecord(String fid, String fname, String fprice, String ftype){
      int s=0;   
    try {
          
            String sql="update  fmenu set fname='"+fname+"',fprice='"+fprice+"',ftype='"+ftype+"' where fid='"+fid+"'";
            s=st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Restauant_Management_System.class.getName()).log(Level.SEVERE, null, ex);
        }
        return s;
    
}
  public ResultSet fgetRecordByID(String fid){
 
    
        try {
            String sql="select * from fmenu where fid="+Integer.parseInt(fid);
            rs=st.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Restauant_Management_System.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
      

}
  
  public ResultSet SgetRecordByID(String fid){
 
    
        try {
            String sql="select * from staffa where s_id="+Integer.parseInt(fid);
            rs=st.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Restauant_Management_System.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
      

}
  
   public ResultSet TRDisplayRecods(){

  String sql="select * from reservationt";
  try{
  rs=st.executeQuery(sql);
  }catch(SQLException e){
  
  System.out.println(e);
  }
  
  return rs;

}
  public ResultSet fDisplayfooRecods(){

  String sql="select * from fmenu";
  try{
  rs=st.executeQuery(sql);
  }catch(SQLException e){
  
  System.out.println(e);
  }
  
  return rs;

}
  public int Addfood(int fid, String fname, int fprice, String ftype) {
    int status = 0;
    try {
        String sql = "INSERT INTO fmenu VALUES ('" + fid + "','" + fname + "','" + fprice + "','" + ftype + "')";
        status = st.executeUpdate(sql);
    } catch (SQLException ex) {
        System.out.println(ex);
    }
    return status;
}
  
  public int Order(int fid1, String fname1, int fprice1, String ftype1, int fquantity, int ftotalprice) {
    int status = 0;
    try {
        String sql = "INSERT INTO orderfood VALUES ('" + fid1 + "','" + fname1 + "','" + fprice1 + "','" + ftype1 + "','" + fquantity + "','" + ftotalprice + "')";
        status = st.executeUpdate(sql);
    } catch (SQLException ex) {
        System.out.println(ex);
    }
    return status;
}
    public ResultSet DisplayOders(){

  String sql="select * from orderfood";
  try{
  rs=st.executeQuery(sql);
  }catch(SQLException e){
  
  System.out.println(e);
  }
  
  
  
  return rs;

}
  public int Addstaff( int sid,String sname, String sposition,int ssalary ) {
    int status = 0;
    try {
        String sql = "INSERT INTO staffa VALUES ('" + sid+ "','" + sname+ "','" +sposition+ "','" + ssalary + "')";
        status = st.executeUpdate(sql);
    } catch (SQLException ex) {
        System.out.println(ex);
    }
    return status;
}
  
  public int Booktable(String RName, int RContact , String REmail,String RCnic,String RTableno, String RTime) {
    int status = 0;
    try {
        String sql = "INSERT INTO reservationt VALUES ('" + RName + "','" + RContact + "','" + REmail + "','" + RCnic + "','" + RTableno+ "','" + RTime+ "')";
        status = st.executeUpdate(sql);
    } catch (SQLException ex) {
        System.out.println(ex);
    }
    return status;
}
  public ResultSet findStaffRecords(String searchdata){

        try {
            String sql="select * from staffa where s_id='"+searchdata+"' or S_Name='"+searchdata+"'";
            rs=st.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Restauant_Management_System.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return rs;
   
}
  
  public ResultSet findRTRecords(String searchdata){

        try {
            String sql="select * from reservationt where RName='"+searchdata+"' or RTableno='"+searchdata+"'";
            rs=st.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Restauant_Management_System.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return rs;
   
}
public int RemoveRecordBYID(String fid){
int s=0;
        try {
            String sql="delete from fmenu  where fid='"+fid+"'";
            System.out.println(sql);
            s=st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Restauant_Management_System.class.getName()).log(Level.SEVERE, null, ex);
        }
     return s;
}
public int RRemoveRecordBYID(String RName){
int s=0;
        try {
            String sql="delete from reservationt  where RName='"+RName+"'";
            System.out.println(sql);
            s=st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Restauant_Management_System.class.getName()).log(Level.SEVERE, null, ex);
        }
     return s;
}
public int RemoveSRecordBYID(String sid){
int s=0;
        try {
            String sql="delete from staffa  where s_id='"+sid+"'";
            System.out.println(sql);
            s=st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Restauant_Management_System.class.getName()).log(Level.SEVERE, null, ex);
        }
     return s;
}
 public ResultSet egetRecordByID(String sid){
 
    
        try {
            String sql="select * from staffa where s_id="+(sid);
            rs=st.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Restauant_Management_System.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
      

}
public ResultSet getfoodRecords(){

  String sql="select * from fmenu";
  try{
  rs=st.executeQuery(sql);
  }catch(SQLException e){
  
  System.out.println(e);
  }
  
  return rs;

}

public ResultSet getstaffRecords(){

  String sql="select * from staffa";
  try{
  rs=st.executeQuery(sql);
  }catch(SQLException e){
  
  System.out.println(e);
  }
  
  return rs;

}



public ResultSet TDisplayRecods(){

  String sql="select * from reservationt";
  try{
  rs=st.executeQuery(sql);
  }catch(SQLException e){
  
  System.out.println(e);
  }
  
  return rs;

}
 public ResultSet getRecordByID(String fid){
 
    
        try {
            String sql="select * from fmenu where fid="+(fid);
            rs=st.executeQuery(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Restauant_Management_System.class.getName()).log(Level.SEVERE, null, ex);
        }
        return rs;
      

}
 
 public int updatestaffRecord(String s_id, String sname, String sposition, String ssalary){
      int s=0;   
    try {
          
            String sql="update staffa set  S_Name='"+sname+"',S_Position='"+sposition+"',S_salary='"+ssalary+"'where s_id='"+s_id+"'";
            s=st.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(Restauant_Management_System.class.getName()).log(Level.SEVERE, null, ex);
        }
        return s;
        
    
}
 public ResultSet gettableRecords(){

  String sql="select * from reservationt";
  try{
  rs=st.executeQuery(sql);
  }catch(SQLException e){
  
  System.out.println(e);
  }
  
  return rs;

}

    public static void main(String[] args) {
        // TODO code application logic here
        Restauant_Management_System db=new Restauant_Management_System();
    }

   
    
}
