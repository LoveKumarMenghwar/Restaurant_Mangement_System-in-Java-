
package restauant_management_system;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class menud extends javax.swing.JFrame {

    
     ResultSet rst;
    public menud() {
        initComponents();
        DefaultTableModel DC=(DefaultTableModel)fdisplay.getModel();
        DC.setRowCount(0);
          Restauant_Management_System Connection=new Restauant_Management_System();
        ResultSet rst = Connection.fDisplayfooRecods();
         try {
             while(rst.next()){
                 String[] data ={rst.getString("fid"),rst.getString("fname"),rst.getString("fprice"),rst.getString("ftype")};
                 DC.addRow(data);
             }    } catch (SQLException ex) {
             Logger.getLogger(menud.class.getName()).log(Level.SEVERE, null, ex);
         }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        fdelete = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        fdisplay = new javax.swing.JTable();
        fadd = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        fprice1 = new javax.swing.JTextField();
        fname1 = new javax.swing.JTextField();
        fid1 = new javax.swing.JTextField();
        ftype1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        find = new javax.swing.JButton();
        search = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        fdelete.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        fdelete.setText("Delete");
        fdelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fdeleteActionPerformed(evt);
            }
        });
        getContentPane().add(fdelete, new org.netbeans.lib.awtextra.AbsoluteConstraints(597, 106, -1, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setText("Menu");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(468, 0, 113, 50));

        fdisplay.setFont(new java.awt.Font("Times New Roman", 0, 16)); // NOI18N
        fdisplay.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Food Name", "Price", "Type"
            }
        ));
        jScrollPane1.setViewportView(fdisplay);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(368, 168, 676, -1));

        fadd.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        fadd.setText("Add");
        fadd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                faddActionPerformed(evt);
            }
        });
        getContentPane().add(fadd, new org.netbeans.lib.awtextra.AbsoluteConstraints(395, 106, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setText("Food Name");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 227, -1, -1));
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 370, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setText("ID");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 106, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setText("Price");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 334, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel6.setText("Type");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 445, 46, -1));
        getContentPane().add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 59, 1071, 10));

        fprice1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        getContentPane().add(fprice1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 379, 280, 43));

        fname1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        getContentPane().add(fname1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 273, 280, 43));

        fid1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        getContentPane().add(fid1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 168, 280, 43));

        ftype1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        getContentPane().add(ftype1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 496, 280, 43));

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jButton1.setText("Update");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(477, 106, -1, -1));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jButton2.setText("Clear");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(703, 106, -1, -1));

        jButton3.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        jButton3.setText("Back");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 567, -1, -1));

        jButton4.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\close.png")); // NOI18N
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1008, 11, -1, -1));

        find.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        find.setText("Search");
        find.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findActionPerformed(evt);
            }
        });
        getContentPane().add(find, new org.netbeans.lib.awtextra.AbsoluteConstraints(962, 108, -1, -1));
        getContentPane().add(search, new org.netbeans.lib.awtextra.AbsoluteConstraints(803, 109, 150, 30));

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 1070, 580));

        jPanel2.setBackground(new java.awt.Color(153, 153, 153));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1070, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1070, 60));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void fdeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fdeleteActionPerformed
        // TODO add your handling code here:
        Restauant_Management_System db=new Restauant_Management_System();
         DefaultTableModel tb=(DefaultTableModel)fdisplay.getModel();
         String rowid=(String) tb.getValueAt(fdisplay.getSelectedRow(),0);
        if(db.RemoveRecordBYID(rowid)==1){
        
            JOptionPane.showMessageDialog(this, "Removed","alert",1);
        }else{
        
        
            JOptionPane.showMessageDialog(this, "ERRor","alert",1);
        }
        
        
                try {
           
            
            rst=db.getfoodRecords();
           tb.setRowCount(0);
            while(rst.next()){
            String data[]={Integer.toString(rst.getInt("fid")),rst.getString("fname"),Integer.toString(rst.getInt("fprice")),rst.getString("ftype")};
            tb.addRow(data);    
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(DisplayfooRecods.class.getName()).log(Level.SEVERE, null, ex);
        }
                                           

  
         
       

   
    }//GEN-LAST:event_fdeleteActionPerformed

    private void faddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_faddActionPerformed
        
Restauant_Management_System db = new Restauant_Management_System();
DefaultTableModel tb=(DefaultTableModel)fdisplay.getModel();
if (db.Addfood(Integer.parseInt(fid1.getText()), fname1.getText(), Integer.parseInt(fprice1.getText()), ftype1.getText()) == 1) {
    JOptionPane.showMessageDialog(this, "Item is added", "Food", JOptionPane.INFORMATION_MESSAGE);
    fid1.setText("");
    fname1.setText("");
    fprice1.setText("");
    ftype1.setText("");
} else {
    JOptionPane.showMessageDialog(this, "Error", "Food", JOptionPane.ERROR_MESSAGE);
  
    }//GEN-LAST:event_faddActionPerformed
   try {
           
            
            rst=db.getfoodRecords();
           tb.setRowCount(0);
            while(rst.next()){
            String data[]={Integer.toString(rst.getInt("fid")),rst.getString("fname"),Integer.toString(rst.getInt("fprice")),rst.getString("ftype")};
            tb.addRow(data);    
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(DisplayfooRecods.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
         Dashboard D =new Dashboard();
        D.setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        fid1.setText("");
        fname1.setText("");
        ftype1.setText("");
        fprice1.setText("");
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        int a=JOptionPane.showConfirmDialog(null,"Do you want to exist","Select",JOptionPane.YES_NO_OPTION);
        if(a==0){
         System.exit(0);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void findActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findActionPerformed
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            Restauant_Management_System db=new Restauant_Management_System();

            ResultSet rs;
            rs=db.findFoodRecords(search.getText());
            DefaultTableModel tb=(DefaultTableModel)fdisplay.getModel();
            tb.setRowCount(0);
            while(rs.next()){
                String data[]={rs.getString("fid"),rs.getString("fname"),rs.getString("fprice"),rs.getString("ftype")};
                tb.addRow(data);

            }
        } catch (SQLException ex) {
            Logger.getLogger(menud.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_findActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
            try {
         // TODO add your handling code here:
         
         DefaultTableModel tb=(DefaultTableModel)fdisplay.getModel();
         //rs=db.SearchbyID(search.getText
         String rowid=(String) tb.getValueAt(fdisplay.getSelectedRow(),0);
         
         Restauant_Management_System db=new Restauant_Management_System();
         System.out.println(rowid);
         
         rst=db.fgetRecordByID(rowid);
         
                 
         
         if(rst.next()){
         System.out.println(rst.getString("fid"));
             updatemenu t=new updatemenu(rst.getString("fid"),rst.getString("fname"),rst.getString("fprice"),rst.getString("ftype"));
             t.setVisible(true);
             
         }
     } catch (SQLException ex) {
         Logger.getLogger(menud.class.getName()).log(Level.SEVERE, null, ex);
     }
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new menud().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton fadd;
    private javax.swing.JButton fdelete;
    private javax.swing.JTable fdisplay;
    private javax.swing.JTextField fid1;
    private javax.swing.JButton find;
    private javax.swing.JTextField fname1;
    private javax.swing.JTextField fprice1;
    private javax.swing.JTextField ftype1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField search;
    // End of variables declaration//GEN-END:variables

    private static class DisplayfooRecods {

        public DisplayfooRecods() {
        }
    }

    static class DisplaystaffRecods {

        public DisplaystaffRecods() {
        }
    }

   

}
